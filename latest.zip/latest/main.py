import os
import requests
import zipfile
import tkinter as tk
from module1 import Module1App
from module2 import Module2App
from module3 import Module3App
from module4 import Module4App
from module5 import Module5App


class MainApp:

    def __init__(self, root):
        self.root = root
        self.root.title("谭玲办公系统")
        self.root.attributes('-topmost', False)  # 设置主窗口不自动跳到最前

        # 使主界面在屏幕中央
        self.center_window(self.root, 700, 500)

        # 创建滚动框架
        self.canvas = tk.Canvas(root)
        self.scrollbar = tk.Scrollbar(root, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = tk.Frame(self.canvas)

        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(
                scrollregion=self.canvas.bbox("all")
            )
        )

        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

        self.canvas.configure(yscrollcommand=self.scrollbar.set)

        # 添加欢迎弹窗
        self.show_welcome_message()

        # 添加主界面标题和功能模块按钮
        self.create_widgets()

        # 检查更新
        self.check_for_update()

    def show_welcome_message(self):
        top = tk.Toplevel(self.root)
        top.attributes('-topmost', False)  # 欢迎消息窗口不自动跳到最前
        top.title("欢迎使用")

        # 设置弹窗大小
        width = 400
        height = 100
        self.center_window(top, width, height)

        label = tk.Label(top, text="欢迎来到谭玲老师个人办公系统", font=("Arial", 15))
        label.pack(expand=True)

        button = tk.Button(top, text="确定", command=top.destroy, font=("Arial", 14))
        button.pack(pady=10)

        top.transient(self.root)  # 使弹窗总在主窗口之上
        top.grab_set()  # 禁止用户与主窗口交互，直到关闭弹窗

    def create_widgets(self):
        # 添加大标题
        title_label = tk.Label(
            self.scrollable_frame,
            text="谭玲老师个人办公系统Dashboard",
            font=("Arial", 30, "bold")
        )
        title_label.pack(pady=20)

        # 创建功能模块按钮
        tk.Button(
            self.scrollable_frame,
            text="文件自动解压及分类",
            command=self.open_module_1,
            font=("Arial", 14)
        ).pack(pady=10)

        tk.Button(
            self.scrollable_frame,
            text="成绩升降对比系统",
            command=self.open_module_2,
            font=("Arial", 14)
        ).pack(pady=10)

        tk.Button(
            self.scrollable_frame,
            text="Excel排序系统",
            command=self.open_module_3,
            font=("Arial", 14)
        ).pack(pady=10)

        tk.Button(
            self.scrollable_frame,
            text="退学处分查询系统",
            command=self.open_module_4,
            font=("Arial", 14)
        ).pack(pady=10)

        tk.Button(
            self.scrollable_frame,
            text="成绩分析系统",
            command=self.open_module_5,
            font=("Arial", 14)
        ).pack(pady=10)

    def open_module_1(self):
        module_window = Module1App(self.root)
        module_window.root.attributes('-topmost', False)  # 模块窗口不自动跳到最前

    def open_module_2(self):
        module_window = Module2App(self.root)
        module_window.root.attributes('-topmost', False)

    def open_module_3(self):
        module_window = Module3App(self.root)
        module_window.root.attributes('-topmost', False)

    def open_module_4(self):
        module_window = Module4App(self.root)
        module_window.root.attributes('-topmost', False)

    def open_module_5(self):
        module_window = Module5App(self.root)
        module_window.root.attributes('-topmost', False)

    def center_window(self, window, width, height):
        # 获取屏幕的宽和高
        screen_width = window.winfo_screenwidth()
        screen_height = window.winfo_screenheight()

        # 计算位置坐标
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)

        # 设置窗口的大小和位置
        window.geometry(f'{width}x{height}+{x}+{y}')

    def check_for_update(self):
        current_version = "2.1.0"  # 本地版本
        update_url = "https://github.com/Air-forcy/TLOS-update-server/raw/main/version.json"

        try:
            response = requests.get(update_url)
            data = response.json()

            server_version = data["version"]
            if server_version != current_version:
                self.show_update_message(data["url"])
            else:
                print("当前已经是最新版本。")
        except Exception as e:
            print(f"检查更新失败: {e}")

    def show_update_message(self, update_url):
        top = tk.Toplevel(self.root)
        top.title("更新提示")

        # 设置弹窗大小
        width = 400
        height = 150
        self.center_window(top, width, height)

        label = tk.Label(top, text="检测到新版本，是否现在更新？", font=("Arial", 15))
        label.pack(expand=True)

        button_frame = tk.Frame(top)
        button_frame.pack(pady=10)

        yes_button = tk.Button(button_frame, text="更新", command=lambda: self.download_and_update(update_url),
                               font=("Arial", 14))
        yes_button.pack(side="left", padx=10)

        no_button = tk.Button(button_frame, text="暂不更新", command=top.destroy, font=("Arial", 14))
        no_button.pack(side="right", padx=10)

        top.transient(self.root)
        top.grab_set()

    def download_and_update(self, update_url):
        try:
            response = requests.get(update_url)
            with open("latest.zip", "wb") as file:
                file.write(response.content)

            with zipfile.ZipFile("latest.zip", 'r') as zip_ref:
                zip_ref.extractall(os.getcwd())  # 解压到当前目录

            os.remove("latest.zip")
            print("更新成功，请重新启动程序。")
        except Exception as e:
            print(f"下载更新失败: {e}")


if __name__ == "__main__":
    root = tk.Tk()
    app = MainApp(root)
    root.mainloop()