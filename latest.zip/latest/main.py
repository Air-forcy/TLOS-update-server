import os
import requests
import zipfile
import json
import sys
import tkinter as tk
import tkinter.font as tkfont
from PIL import Image, ImageTk
from modules.module1 import Module1App
from modules.module2 import Module2App
from modules.module3 import Module3App
from modules.module4 import Module4App
from modules.module5 import Module5App
import shutil

# 打包命令：Pyinstaller -F -w -i TLOS.ico --add-data "assets;assets" --add-data "version.json;." --add-data "modules;modules" main.py

def get_resource_path(relative_path):
    """获取资源文件的绝对路径"""
    base_path = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base_path, 'assets', relative_path)

def get_version_path(relative_path):
    """获取版本文件的绝对路径"""
    base_path = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base_path, relative_path)

class MainApp:
    def __init__(self, root):
        self.root = root

        # 获取版本号并设置窗口标题
        self.version = self.get_local_version()
        self.root.title(f"谭玲办公系统 - 版本 {self.version}")
        self.root.attributes('-topmost', False)

        self.fonts = {
            "华文隶书": "华文隶书",
            "Arial": "Arial",
            "Comic Sans MS": "Comic Sans MS",
            "Times New Roman": "Times New Roman",
            "Courier New": "Courier New",
            "华文新魏": "华文新魏",
            "华文琥珀": "华文琥珀",
            "微软雅黑": "微软雅黑",
            "华文彩云": "华文彩云",
            "Algerian": "Algerian",
            "幼圆": "幼圆",
            "Aa未来黑": "Aa未来黑",
        }

        self.center_window(self.root, 1600, 1000)
        self.canvas = tk.Canvas(root)
        self.scrollbar = tk.Scrollbar(root, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = tk.Frame(self.canvas)

        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(
                scrollregion=self.canvas.bbox("all")
            )
        )

        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)

        self.show_welcome_message()
        self.create_widgets()
        self.check_for_update()

    def get_local_version(self):
        """从版本文件中获取本地版本号"""
        try:
            version_file_path = get_version_path('version.json')
            with open(version_file_path, 'r') as file:
                return json.load(file)['version']
        except FileNotFoundError:
            return "未知"

    def create_font(self, family, size=15):
        """创建字体对象，并处理字体不存在的情况"""
        try:
            return tkfont.Font(family=family, size=size)
        except tk.TclError:
            return tkfont.Font(family="Arial", size=size)

    def get_selected_font(self, font_name, size=15, default_font_name="Arial"):
        """获取选择的字体，如果字体名不存在，则使用默认字体"""
        font_family = self.fonts.get(font_name, self.fonts[default_font_name])
        return self.create_font(font_family, size)

    def create_styled_button(self, text, command, font_name, font_size, width):
        button = tk.Button(
            self.scrollable_frame,
            text=text,
            command=command,
            font=self.get_selected_font(font_name, size=font_size),
            bg="#ADD8E6",
            fg="#8B0000",
            padx=5,
            pady=5,
            relief="raised",
            borderwidth=10,
            width=width
        )
        button.bind("<Enter>", lambda e: e.widget.config(bg="#00CED1"))
        button.bind("<Leave>", lambda e: e.widget.config(bg="#ADD8E6"))
        return button

    def add_custom_text(self, text, x, y, font_name="Arial", font_size=15, font_style="bold", color="#000000"):
        """在主界面的指定位置添加文字，并确保文字显示在最上层"""
        font = self.get_selected_font(font_name, size=font_size)

        if font_style == "bold":
            font.config(weight="bold")
        elif font_style == "italic":
            font.config(slant="italic")
        else:
            font.config(weight="normal", slant="roman")

        label = tk.Label(self.scrollable_frame, text=text, font=font, fg=color, bg=self.root["bg"])
        label.place(x=x, y=y)

    def add_custom_image(self, image_path, x, y, width=None, height=None):
        """在主界面的指定位置添加图片，并确保图片显示在最上层"""
        full_image_path = get_resource_path(image_path)

        image = Image.open(full_image_path)
        if width and height:
            image = image.resize((width, height), Image.LANCZOS)
        photo = ImageTk.PhotoImage(image)

        label = tk.Label(self.scrollable_frame, image=photo, bg=self.root["bg"])
        label.image = photo
        label.place(x=x, y=y)

    def create_widgets(self):
        header_frame = tk.Frame(self.scrollable_frame)
        header_frame.pack(pady=20, padx=20, anchor="nw")

        title_label = tk.Label(
            header_frame,
            text="谭玲老师个人办公系统Dashboard",
            font=self.get_selected_font("华文琥珀", size=60)
        )
        title_label.pack(side="left", pady=50, padx=220)

        self.add_custom_image("logo.png", x=20, y=20, width=200, height=200)

        buttons_frame = tk.Frame(self.scrollable_frame)
        buttons_frame.pack(side="left", padx=50, pady=20, anchor="n")

        self.create_styled_button("文件自动解压及分类", self.open_module_1, "华文彩云", 24, width=20).pack(pady=15, anchor="w")
        self.create_styled_button("成绩升降对比系统", self.open_module_2, "华文彩云", 24, width=20).pack(pady=15, anchor="w")
        self.create_styled_button("Excel排序系统", self.open_module_3, "华文彩云", 24, width=20).pack(pady=15, anchor="w")
        self.create_styled_button("退学处分查询系统", self.open_module_4, "华文彩云", 24, width=20).pack(pady=15, anchor="w")
        self.create_styled_button("成绩分析系统", self.open_module_5, "华文彩云", 24, width=20).pack(pady=15, anchor="w")

        self.add_custom_image("image1.png", x=850, y=350, width=405, height=405)
        self.add_custom_text("更多功能有待开发\n\n  敬请期待...", x=900, y=200, font_name="幼圆", font_size=33, font_style="bold", color="#008B8B")

    def show_welcome_message(self):
        top = tk.Toplevel(self.root)
        top.attributes('-topmost', False)
        top.title("Welcome Back to The TLOS")

        width = 1000
        height = 300
        self.center_window(top, width, height)

        label = tk.Label(top, text="欢迎来到谭玲老师个人办公系统\n祝您办公愉快!", font=self.get_selected_font("Aa未来黑", size=45))
        label.pack(expand=True, pady=25)

        button = tk.Button(top, text="Click Here To Start", command=top.destroy, font=self.get_selected_font("Algerian", size=30))
        button.pack(pady=20)

        top.transient(self.root)
        top.grab_set()

    def open_module_1(self):
        module_window = Module1App(self.root)
        module_window.window.attributes('-topmost', False)

    def open_module_2(self):
        module_window = Module2App(self.root)
        module_window.root.attributes('-topmost', False)

    def open_module_3(self):
        module_window = Module3App(self.root)
        module_window.root.attributes('-topmost', False)

    def open_module_4(self):
        module_window = Module4App(self.root)
        module_window.root.attributes('-topmost', False)

    def open_module_5(self):
        module_window = Module5App(self.root)
        module_window.root.attributes('-topmost', False)

    def center_window(self, window, width, height):
        screen_width = window.winfo_screenwidth()
        screen_height = window.winfo_screenheight()

        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)

        window.geometry(f"{width}x{height}+{x}+{y}")

    def check_for_update(self):
        """检查是否有新版本可用"""
        try:
            response = requests.get("https://vercel-deployment.example.com/api/version")  # 使用你实际的Vercel API路径
            if response.status_code == 200:
                latest_version = response.json().get('version')

                if latest_version > self.version:
                    self.prompt_for_update(latest_version)
        except requests.RequestException as e:
            print(f"无法检查更新: {e}")

    def prompt_for_update(self, latest_version):
        """提示用户更新到最新版本"""
        update_window = tk.Toplevel(self.root)
        update_window.title("更新可用")
        self.center_window(update_window, 400, 200)

        label = tk.Label(update_window, text=f"检测到新版本: {latest_version}\n是否更新?", font=self.get_selected_font("Arial", size=15))
        label.pack(pady=20)

        button_frame = tk.Frame(update_window)
        button_frame.pack(pady=10)

        update_button = tk.Button(button_frame, text="立即更新", command=self.download_update)
        update_button.pack(side="left", padx=10)

        cancel_button = tk.Button(button_frame, text="稍后再说", command=update_window.destroy)
        cancel_button.pack(side="right", padx=10)

    def download_update(self):
        """下载并解压新版本"""
        try:
            response = requests.get("https://tlos-update-server-ns2j4ub7a-air-forcys-projects.vercel.app/api/download",stream=True)
            if response.status_code == 200:
                zip_path = "update.zip"
                with open(zip_path, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        f.write(chunk)

                with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                    zip_ref.extractall("update")

                os.remove(zip_path)
                self.apply_update()
        except requests.RequestException as e:
            print(f"无法下载更新: {e}")

    def apply_update(self):
        """应用下载的新版本"""
        try:
            update_dir = "update"
            for item in os.listdir(update_dir):
                s = os.path.join(update_dir, item)
                d = os.path.join(".", item)
                if os.path.isdir(s):
                    shutil.copytree(s, d, dirs_exist_ok=True)
                else:
                    shutil.copy2(s, d)
            shutil.rmtree(update_dir)
            tk.messagebox.showinfo("更新成功", "应用已成功更新，请重新启动。")
            self.root.quit()
        except Exception as e:
            print(f"应用更新失败: {e}")

if __name__ == "__main__":
    root = tk.Tk()
    app = MainApp(root)
    root.mainloop()


