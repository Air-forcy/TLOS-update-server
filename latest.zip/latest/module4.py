import os
import pandas as pd
import tkinter as tk
from tkinter import filedialog, messagebox
from openpyxl import load_workbook
from openpyxl.styles import Font

class Module4App:
    def __init__(self, root):
        self.root = tk.Toplevel(root)
        self.root.title("退学处分查询系统")

        # 表一选择
        tk.Label(self.root, text="选择包含处分学生信息的文件 (表一):").grid(row=0, column=0, padx=10, pady=5, sticky='e')
        self.table1_entry = tk.Entry(self.root, width=50)
        self.table1_entry.grid(row=0, column=1, padx=10, pady=5)
        tk.Button(self.root, text="浏览", command=lambda: self.select_file(self.table1_entry)).grid(row=0, column=2, padx=10, pady=5)

        # 表二选择
        tk.Label(self.root, text="选择包含学生数据的工作簿 (表二):").grid(row=1, column=0, padx=10, pady=5, sticky='e')
        self.table2_entry = tk.Entry(self.root, width=50)
        self.table2_entry.grid(row=1, column=1, padx=10, pady=5)
        tk.Button(self.root, text="浏览", command=lambda: self.select_file(self.table2_entry)).grid(row=1, column=2, padx=10, pady=5)

        # 表头行数输入
        tk.Label(self.root, text="表一表头所在行号:").grid(row=2, column=0, padx=10, pady=5, sticky='e')
        self.table1_header_entry = tk.Entry(self.root, width=10)
        self.table1_header_entry.grid(row=2, column=1, padx=10, pady=5, sticky='w')
        self.table1_header_entry.insert(0, "2")

        tk.Label(self.root, text="表二表头所在行号:").grid(row=3, column=0, padx=10, pady=5, sticky='e')
        self.table2_header_entry = tk.Entry(self.root, width=10)
        self.table2_header_entry.grid(row=3, column=1, padx=10, pady=5, sticky='w')
        self.table2_header_entry.insert(0, "1")

        # 开始查询按钮
        tk.Button(self.root, text="查询", command=self.start_processing).grid(row=4, column=1, padx=10, pady=20)

    def select_file(self, entry):
        file_path = filedialog.askopenfilename()
        entry.delete(0, tk.END)
        entry.insert(0, file_path)

    def start_processing(self):
        table1_path = self.table1_entry.get()
        table2_path = self.table2_entry.get()
        table1_header = int(self.table1_header_entry.get())
        table2_header = int(self.table2_header_entry.get())
        self.process_tables(table1_path, table2_path, table1_header, table2_header)

    def process_tables(self, table1_path, table2_path, table1_header, table2_header):
        table1 = pd.read_excel(table1_path, header=table1_header - 1)
        table1.columns = table1.columns.str.strip()

        if '处分类别' not in table1.columns:
            raise KeyError("表一中未找到'处分类别'列，请确认列名是否正确。")

        table2_sheets = pd.read_excel(table2_path, sheet_name=None, header=table2_header - 1)

        for sheet_name, df in table2_sheets.items():
            df['是否处分'] = df['身份证号'].map(
                lambda x: table1[table1['身份证号'] == x]['处分类别'].values[0] if x in table1[
                    '身份证号'].values else None)

            df['是否处分'] = df['是否处分'].apply(lambda x: '处分类型标红' if x == '劝其退学' else x)

            table2_sheets[sheet_name] = df

        base_name, ext = os.path.splitext(os.path.basename(table2_path))
        desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
        output_file = os.path.join(desktop_path, f"{base_name} (matched).xlsx")

        with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
            for sheet_name, df in table2_sheets.items():
                df.to_excel(writer, sheet_name=sheet_name, index=False)

        wb = load_workbook(output_file)
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            for row in ws.iter_rows(min_row=2, max_col=ws.max_column, max_row=ws.max_row):
                if row[-1].value == '处分类型标红':
                    row[-1].font = Font(color="FF0000")
                    row[-1].value = '劝其退学'
        wb.save(output_file)

        messagebox.showinfo("处理完成", f"文件已生成：\n{os.path.abspath(output_file)}")

