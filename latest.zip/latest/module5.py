import pandas as pd
import matplotlib.pyplot as plt
from tkinter import *
from tkinter import filedialog, messagebox
from tkinter.scrolledtext import ScrolledText
from openpyxl import Workbook
import os
import matplotlib

# 设置matplotlib的字体为中文支持的字体
matplotlib.rc('font', family='Microsoft YaHei')

class Module5App:
    def __init__(self, root):
        self.root = Tk()
        self.root.title("成绩分析工具")
        self.root.geometry("800x600")

        self.canvas = Canvas(self.root)
        self.scroll_y = Scrollbar(self.root, orient="vertical", command=self.canvas.yview)
        self.canvas_frame = Frame(self.canvas)
        self.canvas.create_window(0, 0, anchor="nw", window=self.canvas_frame)
        self.canvas.update_idletasks()
        self.canvas.config(scrollregion=self.canvas.bbox("all"), yscrollcommand=self.scroll_y.set)

        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.scroll_y.grid(row=0, column=1, sticky="ns")

        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(0, weight=1)

        Label(self.canvas_frame, text="请选择成绩文件 (.xlsx):").grid(row=0, column=0, padx=10, pady=5)
        self.file_path = Entry(self.canvas_frame, width=50)
        self.file_path.grid(row=0, column=1, padx=10, pady=5)
        Button(self.canvas_frame, text="浏览", command=self.browse_file).grid(row=0, column=2, padx=10, pady=5)

        Label(self.canvas_frame, text="科目列名:").grid(row=1, column=0, padx=10, pady=5)
        self.subject_name = Entry(self.canvas_frame, width=20)
        self.subject_name.grid(row=1, column=1, padx=10, pady=5)

        Label(self.canvas_frame, text="姓名列名:").grid(row=2, column=0, padx=10, pady=5)
        self.name_column_entry = Entry(self.canvas_frame, width=20)
        self.name_column_entry.grid(row=2, column=1, padx=10, pady=5)

        Label(self.canvas_frame, text="表头所在行号:").grid(row=3, column=0, padx=10, pady=5)
        self.header_row_entry = Entry(self.canvas_frame, width=10)
        self.header_row_entry.grid(row=3, column=1, padx=10, pady=5)
        self.header_row_entry.insert(0, "1")

        Label(self.canvas_frame, text="及格线:").grid(row=4, column=0, padx=10, pady=5)
        self.pass_threshold = Entry(self.canvas_frame, width=10)
        self.pass_threshold.grid(row=4, column=1, padx=10, pady=5)
        self.pass_threshold.insert(0, "60")

        Label(self.canvas_frame, text="优生线:").grid(row=5, column=0, padx=10, pady=5)
        self.excellent_threshold = Entry(self.canvas_frame, width=10)
        self.excellent_threshold.grid(row=5, column=1, padx=10, pady=5)
        self.excellent_threshold.insert(0, "80")

        Label(self.canvas_frame, text="差生线:").grid(row=6, column=0, padx=10, pady=5)
        self.poor_threshold = Entry(self.canvas_frame, width=10)
        self.poor_threshold.grid(row=6, column=1, padx=10, pady=5)
        self.poor_threshold.insert(0, "40")

        # 等级输入框
        grades_frame = LabelFrame(self.canvas_frame, text="等级设置")
        grades_frame.grid(row=7, column=0, columnspan=3, padx=10, pady=10, sticky="w")

        default_grade_names = ["A", "B", "C", ""]
        default_grade_min_ranks = ["1", "11", "21", ""]
        default_grade_max_ranks = ["10", "20", "42", ""]

        self.grade_entries = []
        self.grade_min_entries = []
        self.grade_max_entries = []

        for i in range(4):
            Label(grades_frame, text=f"等级{i+1}名称:").grid(row=i, column=0, padx=5, pady=2, sticky="e")
            grade_name = Entry(grades_frame, width=10)
            grade_name.grid(row=i, column=1, padx=5, pady=2)
            self.grade_entries.append(grade_name)

            Label(grades_frame, text="最小名次:").grid(row=i, column=2, padx=5, pady=2, sticky="e")
            min_rank = Entry(grades_frame, width=10)
            min_rank.grid(row=i, column=3, padx=5, pady=2)
            self.grade_min_entries.append(min_rank)

            Label(grades_frame, text="最大名次:").grid(row=i, column=4, padx=5, pady=2, sticky="e")
            max_rank = Entry(grades_frame, width=10)
            max_rank.grid(row=i, column=5, padx=5, pady=2)
            self.grade_max_entries.append(max_rank)

        # 分数段输入框
        segments_frame = LabelFrame(self.canvas_frame, text="分数段设置")
        segments_frame.grid(row=8, column=0, columnspan=3, padx=10, pady=10, sticky="w")

        self.segment_min_entries = []
        self.segment_max_entries = []

        for i in range(10):
            Label(segments_frame, text=f"分段{i+1}最小分数:").grid(row=i, column=0, padx=5, pady=2, sticky="e")
            min_score = Entry(segments_frame, width=10)
            min_score.grid(row=i, column=1, padx=5, pady=2)
            self.segment_min_entries.append(min_score)

            Label(segments_frame, text="最大分数:").grid(row=i, column=2, padx=5, pady=2, sticky="e")
            max_score = Entry(segments_frame, width=10)
            max_score.grid(row=i, column=3, padx=5, pady=2)
            self.segment_max_entries.append(max_score)

        # 图表选项
        self.generate_charts_var = BooleanVar(value=True)
        generate_charts_check = Checkbutton(self.canvas_frame, text="生成图表", variable=self.generate_charts_var)
        generate_charts_check.grid(row=9, column=0, columnspan=3, padx=10, pady=10, sticky="w")

        # 分析按钮
        analyze_button = Button(self.canvas_frame, text="分析数据", command=self.analyze_data, bg="#4CAF50", fg="white", width=20, height=2)
        analyze_button.grid(row=10, column=0, columnspan=3, padx=10, pady=10)

        # 清空按钮
        clear_button = Button(self.canvas_frame, text="清空", command=self.clear_file_path, bg="#FFC107", width=10)
        clear_button.grid(row=0, column=3, padx=10, pady=5)

        # 全部清空按钮
        clear_all_button = Button(self.canvas_frame, text="全部清空", command=self.clear_all, bg="#F44336", width=20)
        clear_all_button.grid(row=11, column=0, columnspan=3, padx=10, pady=10)

        # 结果显示框
        self.result_text = ScrolledText(self.canvas_frame, width=80, height=20, font=("Arial", 10))
        self.result_text.grid(row=12, column=0, columnspan=3, padx=10, pady=10)
        self.result_text.configure(state=DISABLED)

        # 更新canvas的scrollregion
        self.canvas_frame.bind("<Configure>", self.on_frame_configure)

        # 绑定鼠标滚轮事件
        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel)  # Windows 和 macOS

        # 初始化默认值
        self.set_default_values()

    def browse_file(self):
        self.file_path.insert(0, filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx")]))

    def analyze_data(self):
        file = self.file_path.get()
        try:
            header_row = int(self.header_row_entry.get()) - 1
            pass_mark = float(self.pass_threshold.get())
            excellent_mark = float(self.excellent_threshold.get())
            poor_mark = float(self.poor_threshold.get())
        except ValueError:
            messagebox.showerror("输入错误", "请确保及格线、优生线和差生线都是有效的数字")
            return

        subject = self.subject_name.get()
        name_column = self.name_column_entry.get()

        if not subject or not name_column:
            messagebox.showerror("输入错误", "科目列名和姓名列名不能为空")
            return

        try:
            grade_names = [self.grade_entries[i].get() for i in range(len(self.grade_entries)) if self.grade_entries[i].get()]
            grade_min_ranks = [int(self.grade_min_entries[i].get()) for i in range(len(self.grade_min_entries)) if self.grade_entries[i].get()]
            grade_max_ranks = [int(self.grade_max_entries[i].get()) for i in range(len(self.grade_max_entries)) if self.grade_entries[i].get()]
        except ValueError:
            messagebox.showerror("输入错误", "等级设置中的名次应为有效数字")
            return

        try:
            segment_min_scores = [float(self.segment_min_entries[i].get()) for i in range(len(self.segment_min_entries)) if self.segment_min_entries[i].get()]
            segment_max_scores = [float(self.segment_max_entries[i].get()) for i in range(len(self.segment_max_entries)) if self.segment_max_entries[i].get()]
        except ValueError:
            messagebox.showerror("输入错误", "分数段设置中的分数应为有效数字")
            return

        self.result_text.configure(state=NORMAL)
        self.result_text.delete(1.0, END)

        try:
            df = pd.read_excel(file, header=header_row)
            score_column = subject
            df = df[[name_column, score_column]]
            df = df.dropna(subset=[score_column])

            df['是否及格'] = df[score_column] >= pass_mark
            df['是否优生'] = df[score_column] >= excellent_mark
            df['是否差生'] = df[score_column] < poor_mark

            pass_count = df['是否及格'].sum()
            excellent_count = df['是否优生'].sum()
            poor_count = df['是否差生'].sum()

            total_students = len(df)
            average_score = df[score_column].mean()
            max_score = df[score_column].max()
            min_score = df[score_column].min()

            # 创建统计文件
            stats_file_name = os.path.join(os.path.expanduser("~/Desktop"), f"{subject}_统计.xlsx")
            stats_df = pd.DataFrame({
                "总人数": [total_students],
                "及格人数": [pass_count],
                "及格率%": [pass_count / total_students * 100],
                "总分": [df[score_column].sum()],
                "平均分": [average_score],
                "优生率%": [excellent_count / total_students * 100],
                "差生率%": [poor_count / total_students * 100],
                "最高分": [max_score],
                "最低分": [min_score]
            })

            for min_score, max_score in zip(segment_min_scores, segment_max_scores):
                segment_count = len(df[(df[score_column] >= min_score) & (df[score_column] <= max_score)])
                stats_df[f"{min_score}-{max_score}"] = [segment_count]

            stats_df.to_excel(stats_file_name, index=False)

            # 创建排序文件
            sorted_file_name = os.path.join(os.path.expanduser("~/Desktop"), f"{subject}_排列.xlsx")
            sorted_df = df[[name_column, score_column]].sort_values(by=score_column, ascending=False)
            sorted_df.to_excel(sorted_file_name, index=False)

            self.result_text.insert(END, f"统计数据已保存到: {stats_file_name}\n")
            self.result_text.insert(END, f"排序数据已保存到: {sorted_file_name}\n")

            # 等级分析
            df['名次'] = df[score_column].rank(ascending=False, method='min')
            # 等级分析部分修改
            grade_summary = {}
            for grade_name, min_rank, max_rank in zip(grade_names, grade_min_ranks, grade_max_ranks):
                grade_students = df[(df['名次'] >= min_rank) & (df['名次'] <= max_rank)].sort_values(by='名次')

                # 将名次相同的学生用括号括起来
                grade_student_names = []
                previous_rank = None
                same_rank_group = []

                for index, row in grade_students.iterrows():
                    current_rank = row['名次']
                    student_name = row[name_column]
                    if current_rank == previous_rank:
                        same_rank_group.append(student_name)
                    else:
                        if same_rank_group:
                            grade_student_names.append("(" + ", ".join(same_rank_group) + ")")
                        same_rank_group = [student_name]
                    previous_rank = current_rank

                if same_rank_group:
                    grade_student_names.append("(" + ", ".join(same_rank_group) + ")")

                grade_summary[grade_name] = ", ".join(grade_student_names)

            self.result_text.insert(END, "\n等级分析:\n")
            for grade_name, students in grade_summary.items():
                self.result_text.insert(END, f"{grade_name} 等级人数: {len(students.split(', '))}, 学生: {students}\n")

            # 分数段分析
            self.result_text.insert(END, "\n分数段分析:\n")
            for min_score, max_score in zip(segment_min_scores, segment_max_scores):
                count = len(df[(df[score_column] >= min_score) & (df[score_column] <= max_score)])
                self.result_text.insert(END, f"{min_score}-{max_score} 分数段人数: {count}\n")

            # 生成图表
            if self.generate_charts_var.get():
                self.generate_charts(df, score_column)

        except Exception as e:
            messagebox.showerror("错误", f"分析失败: {str(e)}")
            return

        self.result_text.configure(state=DISABLED)

    def generate_charts(self, df, score_column):
        # 及格率与优生率饼图
        labels = ['及格', '不及格']
        sizes = [df['是否及格'].sum(), len(df) - df['是否及格'].sum()]
        colors = ['#4CAF50', '#FF5252']

        plt.figure(figsize=(10, 5))
        plt.subplot(1, 2, 1)
        plt.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=140)
        plt.title('及格率')

        labels = ['优生', '非优生']
        sizes = [df['是否优生'].sum(), len(df) - df['是否优生'].sum()]
        colors = ['#2196F3', '#FFEB3B']

        plt.subplot(1, 2, 2)
        plt.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=140)
        plt.title('优生率')

        plt.show()

        # 分数段柱状图
        df[score_column].plot(kind='hist', bins=20, color='#FF9800', edgecolor='black')
        plt.xlabel('分数')
        plt.ylabel('人数')
        plt.title('分数分布')
        plt.grid(True)
        plt.show()

    def clear_file_path(self):
        self.file_path.delete(0, END)

    def clear_all(self):
        self.clear_file_path()
        self.subject_name.delete(0, END)
        self.name_column_entry.delete(0, END)
        self.header_row_entry.delete(0, END)
        self.pass_threshold.delete(0, END)
        self.excellent_threshold.delete(0, END)
        self.poor_threshold.delete(0, END)
        for entry in self.grade_entries + self.grade_min_entries + self.grade_max_entries:
            entry.delete(0, END)
        for entry in self.segment_min_entries + self.segment_max_entries:
            entry.delete(0, END)
        self.result_text.configure(state=NORMAL)
        self.result_text.delete(1.0, END)
        self.result_text.configure(state=DISABLED)

    def set_default_values(self):
        self.grade_entries[0].insert(0, "A")
        self.grade_min_entries[0].insert(0, "1")
        self.grade_max_entries[0].insert(0, "10")
        self.grade_entries[1].insert(0, "B")
        self.grade_min_entries[1].insert(0, "11")
        self.grade_max_entries[1].insert(0, "20")
        self.grade_entries[2].insert(0, "C")
        self.grade_min_entries[2].insert(0, "21")
        self.grade_max_entries[2].insert(0, "42")

        self.segment_min_entries[0].insert(0, "100")
        self.segment_max_entries[0].insert(0, "100")
        self.segment_min_entries[1].insert(0, "90")
        self.segment_max_entries[1].insert(0, "99.5")
        self.segment_min_entries[2].insert(0, "80")
        self.segment_max_entries[2].insert(0, "89.5")
        self.segment_min_entries[3].insert(0, "70")
        self.segment_max_entries[3].insert(0, "79.5")
        self.segment_min_entries[4].insert(0, "60")
        self.segment_max_entries[4].insert(0, "69.5")
        self.segment_min_entries[5].insert(0, "50")
        self.segment_max_entries[5].insert(0, "59.5")
        self.segment_min_entries[6].insert(0, "40")
        self.segment_max_entries[6].insert(0, "49.5")
        self.segment_min_entries[7].insert(0, "0")
        self.segment_max_entries[7].insert(0, "39.5")

    def on_frame_configure(self, event):
        self.canvas.config(scrollregion=self.canvas.bbox("all"))

    def _on_mousewheel(self, event):
        self.canvas.yview_scroll(int(-1*(event.delta/120)), "units")

    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    app = Module5App()
    app.run()

