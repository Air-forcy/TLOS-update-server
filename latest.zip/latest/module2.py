import os
import tkinter as tk
from tkinter import filedialog, messagebox
from openpyxl.styles import Color, Font
import openpyxl
import pandas as pd

class Module2App:
    def __init__(self, master):
        self.master = master
        self.top = tk.Toplevel(master)
        self.top.title("成绩升降对比系统")

        # 使子窗口在主窗口中央
        self.center_window(self.top, 800, 400)

        # 文件路径输入
        self.file_label1 = tk.Label(self.top, text="上学期成绩文件:")
        self.file_label1.grid(row=0, column=0, padx=10, pady=5)
        self.file_entry1 = tk.Entry(self.top, width=50)
        self.file_entry1.grid(row=0, column=1, padx=10, pady=5)
        self.browse_button1 = tk.Button(self.top, text="选择文件", command=self.choose_file1)
        self.browse_button1.grid(row=0, column=2, padx=10, pady=5)

        self.file_label2 = tk.Label(self.top, text="下学期成绩文件:")
        self.file_label2.grid(row=1, column=0, padx=10, pady=5)
        self.file_entry2 = tk.Entry(self.top, width=50)
        self.file_entry2.grid(row=1, column=1, padx=10, pady=5)
        self.browse_button2 = tk.Button(self.top, text="选择文件", command=self.choose_file2)
        self.browse_button2.grid(row=1, column=2, padx=10, pady=5)

        # 列名输入
        self.col_label1 = tk.Label(self.top, text="上学期姓名列名:")
        self.col_label1.grid(row=2, column=0, padx=10, pady=5)
        self.col_entry1 = tk.Entry(self.top)
        self.col_entry1.grid(row=2, column=1, padx=10, pady=5)
        self.col_entry1.insert(0, "姓名")  # 默认值

        self.col_label2 = tk.Label(self.top, text="上学期成绩列名:")
        self.col_label2.grid(row=3, column=0, padx=10, pady=5)
        self.col_entry2 = tk.Entry(self.top)
        self.col_entry2.grid(row=3, column=1, padx=10, pady=5)

        self.col_label3 = tk.Label(self.top, text="下学期姓名列名:")
        self.col_label3.grid(row=4, column=0, padx=10, pady=5)
        self.col_entry3 = tk.Entry(self.top)
        self.col_entry3.grid(row=4, column=1, padx=10, pady=5)
        self.col_entry3.insert(0, "姓名")  # 默认值

        self.col_label4 = tk.Label(self.top, text="下学期成绩列名:")
        self.col_label4.grid(row=5, column=0, padx=10, pady=5)
        self.col_entry4 = tk.Entry(self.top)
        self.col_entry4.grid(row=5, column=1, padx=10, pady=5)

        # 行号输入
        self.row_label1 = tk.Label(self.top, text="上学期列名所在行（默认2）:")
        self.row_label1.grid(row=6, column=0, padx=10, pady=5)
        self.row_entry1 = tk.Entry(self.top)
        self.row_entry1.grid(row=6, column=1, padx=10, pady=5)
        self.row_entry1.insert(0, "2")

        self.row_label2 = tk.Label(self.top, text="下学期列名所在行（默认2）:")
        self.row_label2.grid(row=7, column=0, padx=10, pady=5)
        self.row_entry2 = tk.Entry(self.top)
        self.row_entry2.grid(row=7, column=1, padx=10, pady=5)
        self.row_entry2.insert(0, "2")

        # 处理按钮
        self.submit_button = tk.Button(self.top, text="开始处理并输出", command=self.process_data)
        self.submit_button.grid(row=8, column=1, pady=20)

    def choose_file1(self):
        self.file1 = filedialog.askopenfilename()
        self.file_entry1.delete(0, tk.END)
        self.file_entry1.insert(0, self.file1)

    def choose_file2(self):
        self.file2 = filedialog.askopenfilename()
        self.file_entry2.delete(0, tk.END)
        self.file_entry2.insert(0, self.file2)

    def process_data(self):
        file1 = self.file_entry1.get()
        file2 = self.file_entry2.get()
        name_col1 = self.col_entry1.get()
        score_col1 = self.col_entry2.get()
        name_col2 = self.col_entry3.get()
        score_col2 = self.col_entry4.get()
        row_num1 = int(self.row_entry1.get())
        row_num2 = int(self.row_entry2.get())

        # 验证输入
        if not all([file1, file2, name_col1, score_col1, name_col2, score_col2]):
            messagebox.showerror("错误", "请确保所有字段都已填写！")
            return

        # 读取数据
        df1 = pd.read_excel(file1, header=row_num1 - 1)
        df2 = pd.read_excel(file2, header=row_num2 - 1)

        # 确保列名存在
        if not all([name_col1 in df1.columns, score_col1 in df1.columns,
                    name_col2 in df2.columns, score_col2 in df2.columns]):
            messagebox.showerror("错误", "列名不存在于提供的Excel文件中！")
            return

        # 计算排名
        df1['上学期排名'] = df1[score_col1].rank(method='dense', ascending=False)
        df2['下学期排名'] = df2[score_col2].rank(method='dense', ascending=False)

        # 合并数据
        df_final = pd.merge(df1[[name_col1, '上学期排名']], df2[[name_col2, '下学期排名', score_col2]],
                            left_on=name_col1, right_on=name_col2, how='outer')

        # 计算名次变化
        df_final['名次变化'] = df_final['下学期排名'] - df_final['上学期排名']

        # 生成输出Excel文件并保存在桌面上
        desktop_path = os.path.expanduser("~/Desktop")
        output_filename = os.path.join(desktop_path, f"{score_col2}_compared.xlsx")
        df_final[[name_col1, '上学期排名', '下学期排名', '名次变化']].to_excel(output_filename, index=False)

        # 设置格式
        wb = openpyxl.load_workbook(output_filename)
        ws = wb.active

        # 设置名次变化的字体颜色和加粗
        green_color = Color(rgb='008000')  # 绿色
        green_font = Font(color=green_color, bold=True)  # 设置文本加粗

        red_color = Color(rgb='FF0000')  # 红色
        red_font = Font(color=red_color, bold=True)  # 设置文本加粗

        for row in ws.iter_rows(min_row=2, values_only=False):
            cell = row[3]
            if cell.value:
                if cell.value < 0:  # 进步
                    cell.value = f"↑ {abs(int(cell.value))}"
                    cell.font = green_font
                elif cell.value > 0:  # 退步
                    cell.value = f"↓ {abs(int(cell.value))}"
                    cell.font = red_font

        # 保存Excel文件
        wb.save(output_filename)
        messagebox.showinfo("完成", f"文件已生成，保存为 {output_filename}")

    def center_window(self, window, width, height):
        # 获取屏幕的宽和高
        screen_width = window.winfo_screenwidth()
        screen_height = window.winfo_screenheight()

        # 计算位置坐标
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)

        # 设置窗口的大小和位置
        window.geometry(f'{width}x{height}+{x}+{y}')

