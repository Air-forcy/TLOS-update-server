import pandas as pd
import tkinter as tk
from tkinter import filedialog, messagebox
import os

class Module3App:
    def __init__(self, parent):
        self.parent = parent
        self.root = tk.Toplevel(self.parent)  # 修改为 self.root
        self.root.title("Excel 排序工具")

        # 使窗口在屏幕中央
        self.center_window(self.root, 650, 300)

        # 创建并放置控件
        tk.Label(self.root, text="选择被排序的表格 (表1):").grid(row=0, column=0, padx=10, pady=5)
        self.table1_entry = tk.Entry(self.root, width=50)
        self.table1_entry.grid(row=0, column=1, padx=10, pady=5)
        tk.Button(self.root, text="浏览", command=lambda: self.browse_file(self.table1_entry)).grid(row=0, column=2, padx=10, pady=5)

        tk.Label(self.root, text="选择正序表格 (表2):").grid(row=1, column=0, padx=10, pady=5)
        self.table2_entry = tk.Entry(self.root, width=50)
        self.table2_entry.grid(row=1, column=1, padx=10, pady=5)
        tk.Button(self.root, text="浏览", command=lambda: self.browse_file(self.table2_entry)).grid(row=1, column=2, padx=10, pady=5)

        tk.Label(self.root, text="表1中的排序列名:").grid(row=2, column=0, padx=10, pady=5)
        self.table1_col_entry = tk.Entry(self.root, width=50)
        self.table1_col_entry.grid(row=2, column=1, padx=10, pady=5)

        tk.Label(self.root, text="表2中的排序列名:").grid(row=3, column=0, padx=10, pady=5)
        self.table2_col_entry = tk.Entry(self.root, width=50)
        self.table2_col_entry.grid(row=3, column=1, padx=10, pady=5)

        tk.Button(self.root, text="排序表格", command=self.sort_tables).grid(row=4, column=1, pady=20)

    def browse_file(self, entry):
        """打开文件对话框并将选择的文件路径插入到指定的Entry控件中"""
        file_path = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx")], parent=self.root)
        if file_path:
            entry.delete(0, tk.END)  # 清空Entry控件
            entry.insert(0, file_path)  # 插入文件路径

    def sort_tables(self):
        try:
            # 获取文件路径和列名
            table1_file = self.table1_entry.get()
            table2_file = self.table2_entry.get()
            table1_col = self.table1_col_entry.get()
            table2_col = self.table2_col_entry.get()

            # 检查输入是否为空
            if not table1_file or not table2_file or not table1_col or not table2_col:
                messagebox.showerror("错误", "所有输入字段都不能为空")
                return

            # 读取表1和表2
            table1 = pd.read_excel(table1_file)
            table2 = pd.read_excel(table2_file)

            # 确保表1和表2都包含排序列
            if table1_col not in table1.columns or table2_col not in table2.columns:
                messagebox.showerror("错误", "排序列名在表1或表2中缺失")
                return

            # 按表2中的排序列顺序排序表1
            sorted_table1 = table1.set_index(table1_col).reindex(table2[table2_col]).reset_index()

            # 获取桌面的路径
            desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")

            # 保存排序后的表1到桌面上的一个新Excel文件
            base_name = os.path.splitext(os.path.basename(table1_file))[0]
            sorted_output_file = os.path.join(desktop_path, f'{base_name} (sorted).xlsx')
            sorted_table1.to_excel(sorted_output_file, index=False)

            # 显示成功消息
            messagebox.showinfo("完成", f"排序完成，并保存为 {sorted_output_file}")

        except Exception as e:
            messagebox.showerror("错误", str(e))

    def center_window(self, window, width, height):
        # 获取屏幕的宽和高
        screen_width = window.winfo_screenwidth()
        screen_height = window.winfo_screenheight()

        # 计算位置坐标
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)

        # 设置窗口的大小和位置
        window.geometry(f'{width}x{height}+{x}+{y}')

