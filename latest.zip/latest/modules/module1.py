import shutil
import tkinter as tk
from tkinter import filedialog, Scrollbar, Text, messagebox
import os
import subprocess
import pandas as pd
# 本解压系统支持自动解压".zip", ".rar", ".7z", ".tar", ".gz", ".bz2",
# ".iso", ".cab", ".arj", ".lzma", ".xz", ".z", ".ace",
# ".uue", ".bzip2", ".cbr", ".cbz", ".lha", ".lzh", ".sit",
# "sitx", ".tar.gz", ".tar.bz2", ".tar.xz", ".zipx", ".zpaq", ".zoo"等将近30种类型的压缩文件
# 其中包括了几乎绝大多数常用，不常用，甚至罕见的压缩文件类型，并对解压后的文件进行自动分类打包
class Module1App:
    def __init__(self, parent):
        self.window = tk.Toplevel(parent)
        self.window.title("文件自动批量解压与分类系统")
        self.center_window(self.window, 750, 700)


        # 初始化路径和关键词
        self.source_folder = ''
        self.output_folder = ''
        self.keywords = []
        self.file_types = [".doc", ".docx", ".ppt", ".pptx", ".xls", ".xlsx", ".png", ".jpg", ".mp4"]
        self.file_track = {}  # 用于记录文件的移动轨迹
        self.selected_keyword = tk.StringVar()
        self.process_any_file_type = tk.BooleanVar(value=True)  # 默认勾选处理任何文件类型

        # 创建GUI组件
        self.create_widgets()

    def create_widgets(self):
        # 创建源文件夹输入区域
        frame_source = tk.Frame(self.window)
        frame_source.pack(pady=5, fill=tk.X)
        tk.Label(frame_source, text="源文件夹:").pack(side=tk.LEFT)
        self.source_path_entry = tk.Entry(frame_source, width=60)
        self.source_path_entry.pack(side=tk.LEFT, padx=5)
        tk.Button(frame_source, text="浏览", command=self.browse_source_folder).pack(side=tk.LEFT)

        # 创建输出文件夹输入区域
        frame_output = tk.Frame(self.window)
        frame_output.pack(pady=5, fill=tk.X)
        tk.Label(frame_output, text="输出文件夹:").pack(side=tk.LEFT)
        self.output_path_entry = tk.Entry(frame_output, width=60)
        self.output_path_entry.pack(side=tk.LEFT, padx=5)
        tk.Button(frame_output, text="浏览", command=self.browse_output_folder).pack(side=tk.LEFT)

        # 创建关键词表输入区域
        frame_keywords = tk.Frame(self.window)
        frame_keywords.pack(pady=5, fill=tk.X)
        tk.Label(frame_keywords, text="关键词表:").pack(side=tk.LEFT)
        self.keywords_path_entry = tk.Entry(frame_keywords, width=60)
        self.keywords_path_entry.pack(side=tk.LEFT, padx=5)
        tk.Button(frame_keywords, text="浏览", command=self.browse_keywords_file).pack(side=tk.LEFT)

        # 创建文件类型输入框区域
        frame_file_types = tk.Frame(self.window)
        frame_file_types.pack(pady=5, fill=tk.X)
        tk.Label(frame_file_types, text="文件类型:").pack(side=tk.LEFT)
        self.file_types_entry = tk.Entry(frame_file_types, width=60)
        self.file_types_entry.insert(0, ",".join(self.file_types))  # 默认值
        self.file_types_entry.pack(side=tk.LEFT, padx=5)

        # 创建是否处理任何文件类型的勾选框
        self.any_file_type_check = tk.Checkbutton(frame_file_types, text="处理任何文件类型", variable=self.process_any_file_type)
        self.any_file_type_check.pack(side=tk.LEFT, padx=5)

        # 创建关键词预览框区域
        frame_keywords_preview = tk.Frame(self.window)
        frame_keywords_preview.pack(pady=5, fill=tk.X)
        tk.Label(frame_keywords_preview, text="关键词预览:").pack(side=tk.LEFT)
        self.keywords_preview = Text(frame_keywords_preview, width=60, height=10)
        self.keywords_preview.pack(side=tk.LEFT, padx=5)
        self.keywords_preview_scroll = Scrollbar(frame_keywords_preview, command=self.keywords_preview.yview)
        self.keywords_preview_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.keywords_preview.config(yscrollcommand=self.keywords_preview_scroll.set)
        tk.Button(frame_keywords_preview, text="清空关键词", command=self.clear_keywords).pack(side=tk.RIGHT, padx=5)

        # 启动分类按钮
        tk.Button(self.window, text="启动分类", command=self.start_classification).pack(pady=10)

        # 错误报告区域
        tk.Label(self.window, text="错误报告:").pack()
        self.error_report = Text(self.window, width=80, height=20)
        self.error_report.pack(pady=10)
        self.error_report_scroll = Scrollbar(self.window, command=self.error_report.yview)
        self.error_report_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.error_report.config(yscrollcommand=self.error_report_scroll.set)

        # 文件查询区域
        frame_query = tk.Frame(self.window)
        frame_query.pack(pady=5, fill=tk.X)
        tk.Label(frame_query, text="文件查询:").pack(side=tk.LEFT)
        self.query_entry = tk.Entry(frame_query, width=60)
        self.query_entry.pack(side=tk.LEFT, padx=5)
        tk.Button(frame_query, text="查询", command=self.query_file_track).pack(side=tk.LEFT)

    def browse_source_folder(self):
        self.source_folder = filedialog.askdirectory(parent=self.window)
        if self.source_folder:
            self.source_path_entry.delete(0, tk.END)
            self.source_path_entry.insert(0, self.source_folder)

    def browse_output_folder(self):
        self.output_folder = filedialog.askdirectory(parent=self.window)
        if self.output_folder:
            self.output_path_entry.delete(0, tk.END)
            self.output_path_entry.insert(0, self.output_folder)

    def browse_keywords_file(self):
        keywords_file = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx")], parent=self.window)
        if keywords_file:
            self.keywords_path_entry.delete(0, tk.END)
            self.keywords_path_entry.insert(0, keywords_file)
            self.load_keywords(keywords_file)

    def load_keywords(self, keywords_file):
        try:
            df = pd.read_excel(keywords_file)
            self.keywords = df.iloc[:, 0].tolist()
            self.keywords_preview.delete(1.0, tk.END)
            for idx, keyword in enumerate(self.keywords, 1):
                self.keywords_preview.insert(tk.END, f"{idx}. {keyword}\n")
        except Exception as e:
            self.error_report.insert(tk.END, f"错误报告: {keywords_file} 加载关键词表失败: {e}\n")

    def clear_keywords(self):
        self.keywords = []
        self.keywords_preview.delete(1.0, tk.END)

    def start_classification(self):
        try:
            # 更新文件类型列表
            self.file_types = [ft.strip() for ft in self.file_types_entry.get().split(',')]

            if not self.source_folder or not self.output_folder or not self.keywords:
                messagebox.showwarning("警告", "请确保已导入源文件夹、输出文件夹和关键词表")
                return

            self.error_report.delete(1.0, tk.END)
            self.file_track.clear()  # 清空文件轨迹记录
            self.process_directory(self.source_folder)

            # 调用新添加的函数
            self.clean_unextracted_packages()

            # 在任务完成后弹出统计窗口
            self.show_summary()

        except Exception as e:
            self.error_report.insert(tk.END, f"全局错误报告: {e}\n")
            messagebox.showerror("错误", f"发生了一个意外错误: {e}")

    def process_directory(self, directory):
        for root, dirs, files in os.walk(directory):
            for file in files:
                if any(file.endswith(ext) for ext in [".zip", ".rar", ".7z", ".tar", ".gz", ".bz2", ".iso", ".cab", ".arj", ".lzma", ".xz", ".z", ".ace", ".uue", ".bzip2", ".cbr", ".cbz", ".lha", ".lzh", ".sit", "sitx", ".tar.gz", ".tar.bz2", ".tar.xz", ".zipx", ".zpaq", ".zoo"]):
                    archive_path = os.path.join(root, file)
                    success = self.handle_archive_file(archive_path)
                    if not success:
                        self.move_failed_archive(archive_path)
                elif self.process_any_file_type.get():
                    self.classify_files(root)

    def handle_archive_file(self, archive_path):
        target_dir = os.path.dirname(archive_path)
        extracted_dir = os.path.join(target_dir, os.path.splitext(os.path.basename(archive_path))[0])

        if os.path.exists(extracted_dir):
            self.error_report.insert(tk.END, f"错误报告: {extracted_dir} 跳过解压: 已存在同名文件夹\n")
            return True

        os.makedirs(extracted_dir, exist_ok=True)

        try:
            # 使用 WinRAR 解压支持的所有文件类型
            subprocess.run(['winrar', 'x', '-o+', archive_path, extracted_dir], check=True)

            # 确保解压后文件夹内文件不为空
            if not os.listdir(extracted_dir):
                self.error_report.insert(tk.END, f"错误报告: {archive_path} 解压失败: 解压后的文件夹为空\n")
                return False

            # 防止出现解压后嵌套同名文件夹的情况
            inner_folders = os.listdir(extracted_dir)
            if len(inner_folders) == 1 and os.path.isdir(os.path.join(extracted_dir, inner_folders[0])):
                inner_folder_path = os.path.join(extracted_dir, inner_folders[0])
                if os.path.basename(inner_folder_path) == os.path.basename(extracted_dir):
                    for item in os.listdir(inner_folder_path):
                        shutil.move(os.path.join(inner_folder_path, item), extracted_dir)
                    os.rmdir(inner_folder_path)

            self.process_directory(extracted_dir)
            return True
        except subprocess.CalledProcessError:
            return False
        except Exception as e:
            self.error_report.insert(tk.END, f"错误报告: {archive_path} 处理压缩文件失败: {e}\n")
            return False

    def move_failed_archive(self, archive_path):
        failed_dir = os.path.join(self.output_folder, "Unextracted Packages")
        os.makedirs(failed_dir, exist_ok=True)
        shutil.copy(archive_path, failed_dir)
        self.error_report.insert(tk.END, f"错误报告: {archive_path} 移动失败: 无法解压此文件类型\n")

    def classify_files(self, directory):
        unclassified_folder = os.path.join(self.output_folder, "Unclassified Files")
        os.makedirs(unclassified_folder, exist_ok=True)

        for root, dirs, files in os.walk(directory):
            for file in files:
                # 检查是否是压缩包文件，如果是，移动到“未解压的压缩包”
                if any(file.endswith(ext) for ext in [".zip", ".rar", ".7z", ".tar", ".gz", ".bz2", ".iso", ".cab", ".arj", ".lzma", ".xz", ".z", ".ace", ".uue", ".bzip2", ".cbr", ".cbz", ".lha", ".lzh", ".sit", "sitx", ".tar.gz", ".tar.bz2", ".tar.xz", ".zipx", ".zpaq", ".zoo"]):
                    self.move_failed_archive(os.path.join(root, file))
                    continue

                matching_keywords = []
                for keyword in self.keywords:
                    if keyword in file:
                        matching_keywords.append(keyword)

                if len(matching_keywords) == 1:
                    # 只有一个匹配关键词，直接分类
                    file_ext = os.path.splitext(file)[1]
                    if file_ext in self.file_types:
                        self.copy_file_to_keyword_folder(file, root, matching_keywords[0])
                elif len(matching_keywords) > 1:
                    # 匹配多个关键词，弹出选择对话框
                    chosen_keyword = self.select_keywords(file, matching_keywords)
                    if chosen_keyword:
                        file_ext = os.path.splitext(file)[1]
                        if file_ext in self.file_types:
                            self.copy_file_to_keyword_folder(file, root, chosen_keyword)
                else:
                    # 没有匹配的关键词，放入未分类文件夹
                    shutil.copy(os.path.join(root, file), os.path.join(unclassified_folder, file))
                    self.file_track[file] = f"Unclassified Files/{file}"

    def copy_file_to_keyword_folder(self, file, current_folder, keyword):
        keyword_folder = os.path.join(self.output_folder, keyword)
        os.makedirs(keyword_folder, exist_ok=True)
        shutil.copy(os.path.join(current_folder, file), os.path.join(keyword_folder, file))
        self.file_track[file] = f"{keyword}/{file}"

    def clean_unextracted_packages(self):
        # 检查源文件夹中的压缩包
        for root, dirs, files in os.walk(self.source_folder):
            for file in files:
                if any(file.endswith(ext) for ext in [".zip", ".rar", ".7z", ".tar", ".gz", ".bz2", ".iso", ".cab", ".arj", ".lzma", ".xz", ".z", ".ace", ".uue", ".bzip2", ".cbr", ".cbz", ".lha", ".lzh", ".sit", "sitx", ".tar.gz", ".tar.bz2", ".tar.xz", ".zipx", ".zpaq", ".zoo"]):
                    archive_name = os.path.splitext(file)[0]
                    archive_path = os.path.join(root, file)

                    # 检查是否存在同名文件夹
                    same_name_folder = os.path.join(root, archive_name)
                    if os.path.exists(same_name_folder) and os.path.isdir(same_name_folder):

                        # 检查 Unextracted Packages 文件夹中是否存在同名的压缩包
                        failed_dir = os.path.join(self.output_folder, "Unextracted Packages")
                        failed_archive = os.path.join(failed_dir, file)

                        if os.path.exists(failed_archive):
                            # 删除 Unextracted Packages 文件夹中的压缩包
                            os.remove(failed_archive)
                            self.error_report.insert(tk.END, f"报告: 已删除未成功解压的压缩包: {failed_archive}\n")

    def select_keywords(self, file, matching_keywords):
        dialog = tk.Toplevel(self.window)
        dialog.title(f"选择关键词 - {file}")
        dialog.transient(self.window)  # 确保对话框为主窗口的子窗口

        tk.Label(dialog, text=f"文件 '{file}' 匹配到多个关键词，请选择一个关键词:").pack(pady=10)

        selected_keyword = tk.StringVar()
        for keyword in matching_keywords:
            tk.Radiobutton(dialog, text=keyword, variable=selected_keyword, value=keyword).pack(anchor=tk.W)

        def on_confirm():
            dialog.destroy()

        tk.Button(dialog, text="确定", command=on_confirm).pack(pady=10)

        dialog.wait_window(dialog)
        return selected_keyword.get()

    def show_summary(self):
        total_files = 0
        classified_files = 0
        unclassified_files = 0
        failed_files = 0

        for root, dirs, files in os.walk(self.output_folder):
            for file in files:
                total_files += 1
                if "Unextracted Packages" in root:
                    failed_files += 1
                elif "Unclassified Files" in root:
                    unclassified_files += 1
                else:
                    classified_files += 1

        summary_message = (
            f"总文件数: {total_files}\n"
            f"已分类文件数: {classified_files}\n"
            f"未分类文件数: {unclassified_files}\n"
            f"解压失败的压缩包数: {failed_files}\n"
        )

        messagebox.showinfo("分类结果", summary_message)

    def query_file_track(self):
        file_name = self.query_entry.get().strip()
        if file_name in self.file_track:
            messagebox.showinfo("查询结果", f"文件 '{file_name}' 已移动至: {self.file_track[file_name]}")
        else:
            messagebox.showinfo("查询结果", f"未找到文件 '{file_name}' 的移动轨迹")

    def center_window(self, window, width, height):
        # 获取屏幕的宽和高
        screen_width = window.winfo_screenwidth()
        screen_height = window.winfo_screenheight()

        # 计算位置坐标
        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)

        # 设置窗口的大小和位置
        window.geometry(f'{width}x{height}+{x}+{y}')


